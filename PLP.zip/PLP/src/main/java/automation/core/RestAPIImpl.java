package automation.core;

public class RestAPIImpl {

}
